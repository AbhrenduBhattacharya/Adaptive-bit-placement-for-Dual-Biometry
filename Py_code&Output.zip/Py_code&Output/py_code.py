import cv2
import numpy as np
import pywt
from scipy.fftpack import dct, idct
import os
import matplotlib.pyplot as plt

# ========== Utility ==========


def ensure_dir(path):
    """Ensure directory exists for a file path."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path


# ========== Core DCT Functions ==========


def apply_dct(block):
    return dct(dct(block.T, norm="ortho").T, norm="ortho")


def apply_idct(block):
    return idct(idct(block.T, norm="ortho").T, norm="ortho")


# ========== Bitstream Conversion ==========


def image_to_bitstream(img, size=(64, 64)):
    resized = cv2.resize(img, size)
    return np.unpackbits(resized.astype(np.uint8)).flatten()


# ========== Embedding Logic ==========


def embed_bits(dct_band, bitstream, threshold=30):
    flat = dct_band.flatten()
    indices = np.where(flat > threshold)[0]
    used = indices[: min(len(bitstream), len(indices))]
    for i, bit in enumerate(bitstream[: len(used)]):
        flat[used[i]] = (int(flat[used[i]]) & ~1) | bit
    return flat.reshape(dct_band.shape), len(used)


# ========== Histogram Plotting ==========


def plot_histogram(image, title, color, save_path):
    save_path = ensure_dir(f"Output/Histogram/{save_path}")
    plt.figure(figsize=(8, 5))
    plt.hist(image.flatten(), bins=256, color=color, alpha=0.7)
    plt.title(title)
    plt.xlabel("Pixel Intensity (0–255)")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig(f"{save_path}", dpi=300)
    print(f"[#] Saved: {save_path}")
    plt.close()


def plot_dual_histogram(img1, img2, label1, label2, save_path):
    save_path = ensure_dir(f"Output/Histogram/{save_path}")
    plt.figure(figsize=(10, 5))
    plt.hist(img1.flatten(), bins=256, alpha=0.5, label=label1, color="blue")
    plt.hist(img2.flatten(), bins=256, alpha=0.5, label=label2, color="red")
    plt.title("Pixel Intensity Histogram Comparison")
    plt.xlabel("Pixel Value")
    plt.ylabel("Frequency")
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"{save_path}", dpi=300)
    print(f"[#] Saved: {save_path}")
    plt.close()


def plot_dct_histograms(before_bands, after_bands, titles, save_path):
    save_path = ensure_dir(f"Output/Histogram/{save_path}")
    fig, axs = plt.subplots(2, 2, figsize=(12, 8))
    for i, (before, after, title) in enumerate(zip(before_bands, after_bands, titles)):
        ax = axs[i // 2, i % 2]
        ax.hist(before.flatten(), bins=40, alpha=0.5, label="Before", color="blue")
        ax.hist(after.flatten(), bins=40, alpha=0.5, label="After", color="green")
        ax.set_title(f"DCT Histogram - {title}")
        ax.set_xlabel("Coefficient Value")
        ax.set_ylabel("Frequency")
        ax.legend()
    plt.tight_layout()
    plt.savefig(f"{save_path}", dpi=300)
    print(f"[#] Saved: {save_path}")
    plt.close()


def dump_histogram_hex(image, label, output_file):
    save_path = ensure_dir(f"Output/HexFiles/{output_file}")
    hist = cv2.calcHist([image], [0], None, [256], [0, 256]).flatten().astype(int)
    with open(save_path, "w") as f:
        f.write(f"{label} Histogram (Pixel Intensity -> Count in Hex):\n\n")
        for i, val in enumerate(hist):
            f.write(f"{i:02X}: {val:08X}\n")
    print(f"[#] Hex histogram dumped: {save_path}")


# ========== Main Embedding ==========


def adaptive_embedding(cover_path1, cover_path2, signature_path, fingerprint_path):
    pepper = cv2.imread(cover_path2, cv2.IMREAD_GRAYSCALE)
    house = cv2.imread(cover_path1, cv2.IMREAD_GRAYSCALE)

    signature = cv2.imread(signature_path, cv2.IMREAD_GRAYSCALE)
    fingerprint = cv2.imread(fingerprint_path, cv2.IMREAD_GRAYSCALE)

    if pepper is None or house is None or signature is None or fingerprint is None:
        print("[!] Failed to load one or more input images.")
        return

    def process_cover(cover_img, cover_name):
        cover_img = cv2.resize(cover_img, (256, 256))

        # Save original histogram
        plot_histogram(
            cover_img,
            f"Original {cover_name} Histogram",
            "red",
            f"{cover_name}_Histogram.png",
        )

        # DWT decomposition
        LL, (LH, HL, HH) = pywt.dwt2(cover_img, "haar")

        # DCT on sub-bands
        dct_LL, dct_LH, dct_HL, dct_HH = map(apply_dct, [LL, LH, HL, HH])

        # Prepare bitstreams
        sig_bits = image_to_bitstream(signature)
        fp_bits = image_to_bitstream(fingerprint)

        # Embed into HL and LH
        dct_HL_embed, used_sig = embed_bits(dct_HL.copy(), sig_bits)
        dct_LH_embed, used_fp = embed_bits(dct_LH.copy(), fp_bits)

        # Inverse transforms
        HL_rec = apply_idct(dct_HL_embed)
        LH_rec = apply_idct(dct_LH_embed)
        stego = pywt.idwt2((LL, (LH_rec, HL_rec, HH)), "haar")
        stego = np.clip(stego, 0, 255).astype(np.uint8)

        # Plot histograms
        plot_dct_histograms(
            [dct_LL, dct_LH, dct_HL, dct_HH],
            [dct_LL, dct_LH_embed, dct_HL_embed, dct_HH],
            ["LL", "LH", "HL", "HH"],
            f"{cover_name}_vs_Stego_DCT_Histogram_Comparison.png",
        )
        plot_histogram(
            stego,
            f"{cover_name} Stego Histogram",
            "red",
            f"{cover_name}_Stego_Histogram.png",
        )
        plot_dual_histogram(
            cover_img,
            stego,
            f"{cover_name} Image",
            f"{cover_name} Stego Image",
            f"{cover_name}_vs_Stego_Dual_Comparison_Histogram.png",
        )

        # Save stego image
        out_path = ensure_dir(f"Output/StegoImages/{cover_name}_Stego_Image.png")
        cv2.imwrite(out_path, stego)
        print(f"[#] Stego image saved: {out_path}")
        print(f"[i] Embedded bits — Signature: {used_sig}, Fingerprint: {used_fp}")

        # Dump histogram in hex
        dump_histogram_hex(cover_img, cover_name, f"{cover_name}_Histogram_Hex.txt")
        dump_histogram_hex(
            stego, f"{cover_name}_Stego", f"{cover_name}_Stego_Histogram_Hex.txt"
        )

    # Process both Pepper and House
    process_cover(pepper, "Pepper")
    process_cover(house, "House")


# ========== Entry Point ==========

if __name__ == "__main__":
    root_path = "Images/"
    adaptive_embedding(
        cover_path1=f"{root_path}cover1.tiff",
        cover_path2=f"{root_path}cover2.tiff",
        signature_path=f"{root_path}Secret1.jpg",
        fingerprint_path=f"{root_path}Secret2.jpg",
    )
